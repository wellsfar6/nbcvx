<?php
/**
 * AntiBot Shield - full safe implementation
 * - Place this file in a safe include path: include/antibot.php
 * - include_once 'path/to/antibot.php';
 * - Call antibot_run_light() at top of pages
 * - For forms: call antibot_protect_form() inside <form>
 * - On form handlers: call antibot_validate_request() before processing
 *
 * Notes:
 * - This script is intentionally conservative and challenge-first (doesn't hard-block
 *   datacenter/Tor IPs immediately; it issues a JS challenge first).
 * - It attempts to resolve the real client IP when behind Cloudflare by verifying
 *   the remote address is actually a Cloudflare edge (downloaded list).
 * - Replace or extend file-based storage with Redis/APCu/DB for higher scale.
 */

if (!defined('ANTIBOT_SHIELD')) define('ANTIBOT_SHIELD', true);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/* ================== Configuration ================== */
$ANTIBOT_CONFIG = [
    'data_dir' => __DIR__ . '/antibot_data',
    'rate_limit_window' => 60,     // seconds
    'rate_limit_max' => 30,        // requests per window
    'form_abuse_threshold' => 10,  // submissions before temp block
    'min_form_fill_time' => 2,     // seconds
    'min_activity_score' => 3,     // from JS
    'log_file' => __DIR__ . '/antibot_data/antibot.log',
    'allow_ips' => [],             // admin allowlist
    'block_ips' => [],             // hard blocklist
    'cf_ip_cache_ttl' => 24*3600,  // Cloudflare IP list cache TTL
    'tor_cache_ttl' => 3600,       // Tor list TTL
    'challenge_difficulty_hex_prefix' => '00', // require hash hex to start with this (proof-of-work)
];

/* =============== Ensure data dir exists =============== */
if (!file_exists($ANTIBOT_CONFIG['data_dir'])) {
    @mkdir($ANTIBOT_CONFIG['data_dir'], 0755, true);
}

/* =============== Basic helpers (file-based) =============== */
function antibot_data_file($name) {
    global $ANTIBOT_CONFIG;
    return rtrim($ANTIBOT_CONFIG['data_dir'], '/\\') . '/' . preg_replace('/[^a-z0-9_\\-\\.]/i', '_', $name) . '.json';
}
function antibot_read_json($name) {
    $f = antibot_data_file($name);
    if (!file_exists($f)) return [];
    $c = @file_get_contents($f);
    if ($c === false) return [];
    $j = @json_decode($c, true);
    return is_array($j) ? $j : [];
}
function antibot_write_json($name, $data) {
    $f = antibot_data_file($name);
    @file_put_contents($f, json_encode($data), LOCK_EX);
}
function antibot_log($msg) {
    global $ANTIBOT_CONFIG;
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $ip . ' ' . ($_SERVER['REQUEST_URI'] ?? '') . ' -- ' . $msg . PHP_EOL;
    @file_put_contents($ANTIBOT_CONFIG['log_file'], $line, FILE_APPEND | LOCK_EX);
}

/* ================= Cloudflare-safe client IP resolution ================ */
/**
 * Return the best client IP, trusting CF headers only when REMOTE_ADDR is a Cloudflare IP.
 */
function antibot_get_client_ip() {
    $remote = $_SERVER['REMOTE_ADDR'] ?? '';
    if ($remote && antibot_is_cloudflare_proxy($remote)) {
        // prefer CF header
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = trim(explode(',', $_SERVER['HTTP_CF_CONNECTING_IP'])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
        // fallback to X-Forwarded-For
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $first = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
            if (filter_var($first, FILTER_VALIDATE_IP)) return $first;
        }
        if (!empty($_SERVER['HTTP_X_REAL_IP']) && filter_var($_SERVER['HTTP_X_REAL_IP'], FILTER_VALIDATE_IP)) {
            return $_SERVER['HTTP_X_REAL_IP'];
        }
    }
    return $remote ?: '0.0.0.0';
}

function antibot_is_cloudflare_proxy($ip) {
    global $ANTIBOT_CONFIG;
    $cache_dir = $ANTIBOT_CONFIG['data_dir'];
    $v4_cache = $cache_dir . '/cf_ips_v4.txt';
    $v6_cache = $cache_dir . '/cf_ips_v6.txt';
    $ttl = $ANTIBOT_CONFIG['cf_ip_cache_ttl'];

    $fetch_if_needed = function($url, $dest) use ($ttl) {
        if (file_exists($dest) && (time() - filemtime($dest) < $ttl)) {
            return @file_get_contents($dest);
        }
        $opts = ['http'=>['timeout'=>5,'user_agent'=>'AntiBotShield/1.0']];
        $ctx = stream_context_create($opts);
        $content = @file_get_contents($url, false, $ctx);
        if ($content !== false) @file_put_contents($dest, $content, LOCK_EX);
        if (file_exists($dest)) return @file_get_contents($dest);
        return false;
    };

    $v4 = $fetch_if_needed('https://www.cloudflare.com/ips-v4', $v4_cache);
    $v6 = $fetch_if_needed('https://www.cloudflare.com/ips-v6', $v6_cache);

    if ($v4 === false && $v6 === false) {
        // cannot determine - do not trust CF headers
        return false;
    }
    $ranges = [];
    if ($v4 !== false) {
        foreach (preg_split("/\r?\n/", trim($v4)) as $l) if (strlen(trim($l))) $ranges[] = trim($l);
    }
    if ($v6 !== false) {
        foreach (preg_split("/\r?\n/", trim($v6)) as $l) if (strlen(trim($l))) $ranges[] = trim($l);
    }
    foreach ($ranges as $cidr) {
        if (antibot_ip_in_cidr($ip, $cidr)) return true;
    }
    return false;
}

function antibot_ip_in_cidr($ip, $cidr) {
    if (strpos($cidr, '/') === false) return $ip === $cidr;
    list($net, $mask) = explode('/', $cidr);
    $ip_bin = @inet_pton($ip);
    $net_bin = @inet_pton($net);
    if ($ip_bin === false || $net_bin === false) return false;
    if (strlen($ip_bin) !== strlen($net_bin)) return false;
    $mask = (int)$mask;
    $full_bytes = intdiv($mask, 8);
    $remaining_bits = $mask % 8;
    if ($full_bytes > 0) {
        if (substr($ip_bin, 0, $full_bytes) !== substr($net_bin, 0, $full_bytes)) return false;
    }
    if ($remaining_bits > 0) {
        $byte_ip = ord($ip_bin[$full_bytes]);
        $byte_net = ord($net_bin[$full_bytes]);
        $mask_byte = (~((1 << (8 - $remaining_bits)) - 1)) & 0xFF;
        if ((($byte_ip & $mask_byte) ^ ($byte_net & $mask_byte)) !== 0) return false;
    }
    return true;
}

/* ============== Rate limiting (uses resolved client IP) ============== */
function antibot_check_rate_limit() {
    global $ANTIBOT_CONFIG;
    $ip = antibot_get_client_ip();

    if (in_array($ip, $ANTIBOT_CONFIG['allow_ips'])) return true;
    if (in_array($ip, $ANTIBOT_CONFIG['block_ips'])) {
        antibot_log('Blocked: configured block_ips');
        antibot_kill();
    }
    // temp blocks
    if (antibot_is_blocked_ip($ip)) { antibot_log('Blocked: temp block'); antibot_kill(); }

    $key = 'ip_hits_' . str_replace(':', '_', $ip);
    $data = antibot_read_json($key);
    $now = time();
    $window = $ANTIBOT_CONFIG['rate_limit_window'];
    // keep timestamps only within window
    $data = array_filter($data, function($t) use ($now, $window) { return ($t > $now - $window); });
    $data[] = $now;
    antibot_write_json($key, $data);

    if (count($data) > $ANTIBOT_CONFIG['rate_limit_max']) {
        antibot_log('Rate limit exceeded: ' . count($data) . ' requests in ' . $window . 's');
        antibot_kill();
    }
    return true;
}

/* ================ Form protection helpers ================= */
function antibot_generate_token() {
    if (empty($_SESSION['antibot_token'])) {
        $_SESSION['antibot_token'] = bin2hex(random_bytes(16));
        $_SESSION['antibot_token_time'] = time();
    }
    return $_SESSION['antibot_token'];
}
function antibot_validate_token($token) {
    if (empty($_SESSION['antibot_token'])) return false;
    if (!hash_equals($_SESSION['antibot_token'], $token)) return false;
    if (isset($_SESSION['antibot_token_time']) && (time() - $_SESSION['antibot_token_time']) > 3600) return false;
    unset($_SESSION['antibot_token'], $_SESSION['antibot_token_time']);
    return true;
}

function antibot_protect_form() {
    $token = antibot_generate_token();
    $honeypot_name = 'hp_' . substr(bin2hex(random_bytes(4)), 0, 8);
    echo "\n<!-- AntiBot Shield - begin -->\n";
    echo "<input type=\"hidden\" name=\"antibot_token\" value=\"" . htmlspecialchars($token, ENT_QUOTES) . "\" />\n";
    echo "<div style=\"display:none!important;opacity:0;height:0;width:0;overflow:hidden;position:absolute;left:-9999px;\">";
    echo "<label>Leave this field empty</label><input type=\"text\" name=\"" . htmlspecialchars($honeypot_name, ENT_QUOTES) . "\" value=\"\" />";
    echo "</div>\n";
    $_SESSION['antibot_honeypot'] = $honeypot_name;

    // JS snippet
    $js = <<<'JS'
<script>/* AntiBot Shield client helper */(function(){
window._ab_load_ts = Math.floor(Date.now()/1000);
window._ab_score = 0;
function bump(){ window._ab_score++; }
document.addEventListener('mousemove', bump);
document.addEventListener('scroll', bump);
document.addEventListener('keydown', bump);
function onSubmit(e){
  var form = e.target;
  var h1 = document.createElement('input'); h1.type='hidden'; h1.name='antibot_load_ts'; h1.value = window._ab_load_ts; form.appendChild(h1);
  var h2 = document.createElement('input'); h2.type='hidden'; h2.name='antibot_activity_score'; h2.value = window._ab_score; form.appendChild(h2);
}
var forms = document.getElementsByTagName('form');
for(var i=0;i<forms.length;i++){ forms[i].addEventListener('submit', onSubmit); }
})();</script>
JS;
    echo $js;
    echo "<!-- AntiBot Shield - end -->\n";
}

/* ============== Form validation (call in POST handler) ============== */
function antibot_validate_request() {
    global $ANTIBOT_CONFIG;
    antibot_check_rate_limit();

    $ip = antibot_get_client_ip();
    if (in_array($ip, $ANTIBOT_CONFIG['allow_ips'])) return true;
    if (in_array($ip, $ANTIBOT_CONFIG['block_ips'])) { antibot_log('Blocked by configuration block_ips'); antibot_kill(); }

    // Honeypot
    if (!empty($_SESSION['antibot_honeypot'])) {
        $hp = $_SESSION['antibot_honeypot'];
        if (!empty($_POST[$hp]) || !empty($_REQUEST[$hp])) {
            antibot_log('Honeypot triggered (field: ' . $hp . ')');
            antibot_increment_form_abuse($ip);
            antibot_kill();
        }
    }

    // Token
    $token = $_POST['antibot_token'] ?? $_REQUEST['antibot_token'] ?? '';
    if (!antibot_validate_token($token)) {
        antibot_log('Invalid or missing antibot_token');
        antibot_increment_form_abuse($ip);
        antibot_kill();
    }

    // Timing & Activity
    $load_ts = intval($_POST['antibot_load_ts'] ?? 0);
    $score = intval($_POST['antibot_activity_score'] ?? 0);
    $now = time();
    if ($load_ts > 0) {
        $diff = $now - $load_ts;
        if ($diff < $ANTIBOT_CONFIG['min_form_fill_time']) {
            antibot_log('Form submitted too quickly: ' . $diff . 's');
            antibot_increment_form_abuse($ip);
            antibot_kill();
        }
    }
    if ($score < $ANTIBOT_CONFIG['min_activity_score']) {
        antibot_log('Low activity score: ' . $score);
        antibot_increment_form_abuse($ip);
        antibot_kill();
    }

    // Basic headers check
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
    if (empty($ua) || empty($accept)) {
        antibot_log('Missing UA or Accept header');
        antibot_kill();
    }

    // passed
    return true;
}

function antibot_increment_form_abuse($ip) {
    global $ANTIBOT_CONFIG;
    $key = 'form_abuse_' . str_replace(':','_',$ip);
    $data = antibot_read_json($key);
    $data['count'] = ($data['count'] ?? 0) + 1;
    $data['last'] = time();
    antibot_write_json($key, $data);
    if ($data['count'] >= $ANTIBOT_CONFIG['form_abuse_threshold']) {
        antibot_log('IP added to temp block due to repeated form abuse: ' . $ip);
        $blocks = antibot_read_json('blocks');
        $blocks[$ip] = time();
        antibot_write_json('blocks', $blocks);
    }
}
function antibot_is_blocked_ip($ip) {
    $blocks = antibot_read_json('blocks');
    if (isset($blocks[$ip])) {
        if (time() - $blocks[$ip] < 24*3600) return true;
        unset($blocks[$ip]); antibot_write_json('blocks', $blocks); return false;
    }
    return false;
}

function antibot_kill($status = 404) {
    http_response_code($status);
    echo "<h1>Not Found</h1>";
    exit();
}

/* ====== Proxy/Datacenter/Tor detection helpers and challenge-first logic ====== */
function antibot_reverse_dns_contains($ip, $keywords = []) {
    $host = @gethostbyaddr($ip);
    if (!$host) return false;
    $host_l = strtolower($host);
    foreach ($keywords as $kw) if (strpos($host_l, strtolower($kw)) !== false) return true;
    return false;
}

function antibot_get_asn_info($ip) {
    $cache_dir = __DIR__ . '/antibot_data';
    $cfile = $cache_dir . '/asn_' . str_replace(':','_',$ip) . '.json';
    if (file_exists($cfile) && (time() - filemtime($cfile) < 86400)) {
        $j = @json_decode(@file_get_contents($cfile), true);
        if ($j) return $j;
    }
    $sock = @fsockopen('whois.cymru.com', 43, $errno, $errstr, 3);
    if (!$sock) return false;
    $query = "{$ip}\r\n";
    fwrite($sock, $query);
    stream_set_timeout($sock, 3);
    $resp = '';
    while (!feof($sock)) { $resp .= fgets($sock, 4096); }
    fclose($sock);
    if (!$resp) return false;
    $lines = preg_split('/\r?\n/', trim($resp));
    foreach ($lines as $line) {
        if (stripos($line, 'AS') !== false && stripos($line, $ip) !== false) {
            $parts = array_map('trim', preg_split('/\\|/', $line));
            if (count($parts) >= 6) {
                $asn = $parts[0];
                $owner = $parts[5];
                $out = ['asn' => $asn, 'owner' => $owner];
                @file_put_contents($cfile, json_encode($out), LOCK_EX);
                return $out;
            }
        }
    }
    return false;
}

function antibot_detect_proxy_datacenter($ip) {
    $dns_keywords = ['amazonaws','amazon','aws','google','googleusercontent','cloudflare','cloudfront',
        'digitalocean','linode','ovh','rackspace','fastly','akamaiedge','akamai','microsoft','azure',
        'hetzner','scaleway','vultr','gcore','cdn77','edgecast','softlayer','ibm'];
    if (antibot_reverse_dns_contains($ip, $dns_keywords)) {
        return ['type'=>'rdns','reason'=>'reverse-dns matched provider keywords'];
    }
    $asn = antibot_get_asn_info($ip);
    if ($asn && preg_match('/(GOOGLE|AMAZON|AMAZON-EC2|AMAZON.*AWS|MICROSOFT|CLOUDFLARE|DIGITALOCEAN|OVH|LINODE|VULTR|HETZNER|AKAMAI|FASTLY|SOFTLAYER|IBM)/i', $asn['owner'])) {
        return ['type'=>'asn','reason'=>'asn owner matched: ' . $asn['owner']];
    }
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (empty($ua) || preg_match('/(curl|python-requests|libwww-perl|wget|php|httpclient)/i', $ua)) {
        return ['type'=>'ua','reason'=>'suspicious or empty user-agent'];
    }
    return false;
}

function antibot_is_tor_exit($ip) {
    global $ANTIBOT_CONFIG;
    $cache_dir = $ANTIBOT_CONFIG['data_dir'];
    $file = $cache_dir . '/tor_exit_list.txt';
    $ttl = $ANTIBOT_CONFIG['tor_cache_ttl'];
    if (!file_exists($file) || (time() - filemtime($file) > $ttl)) {
        $content = @file_get_contents('https://check.torproject.org/exit-addresses');
        if ($content !== false) @file_put_contents($file, $content, LOCK_EX);
    }
    if (!file_exists($file)) return false;
    $txt = @file_get_contents($file);
    if (!$txt) return false;
    return (strpos($txt, $ip) !== false);
}

/* Challenge: show JS proof-of-work page and exit.
 * The challenge places a session nonce and expects the client to find a counter such that:
 * hex(sha256(nonce . counter)) starts with configured prefix (low difficulty).
 * Client sends back nonce, counter, hash by POST. Server verifies and sets session flag.
 */
function antibot_show_js_challenge_and_exit($reason = '') {
    global $ANTIBOT_CONFIG;
    // set challenge nonce in session
    $_SESSION['antibot_challenge_nonce'] = bin2hex(random_bytes(12));
    $_SESSION['antibot_challenge_time'] = time();
    $nonce = $_SESSION['antibot_challenge_nonce'];
    $prefix = $ANTIBOT_CONFIG['challenge_difficulty_hex_prefix'];
    // store original requested URL to return after success
    $return_url = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '/', ENT_QUOTES);
    antibot_log('Issuing JS challenge: ' . $reason);
    // Output challenge HTML+JS
    http_response_code(200);
    echo "<!doctype html>\n<html><head><meta charset='utf-8'><title>Checking...</title></head><body>\n";
    echo "<h1>Checking your browser...</h1>\n<p>Please wait — this helps protect the site from automated traffic.</p>\n";
    // Minimal CSS
    echo "<style>body{font-family:Arial,Helvetica,sans-serif;margin:40px;color:#333}</style>";
    // JS: find counter so SHA-256(nonce + counter) hex startsWith prefix, then POST back
    $js = <<<JSC
<script>
(async function(){
  const nonce = "{$nonce}";
  const prefix = "{$prefix}";
  const returnUrl = "{$return_url}";
  function toHex(buffer){ return Array.from(new Uint8Array(buffer)).map(b=>b.toString(16).padStart(2,'0')).join(''); }
  async function sha256hex(msg){
    const enc = new TextEncoder();
    const data = enc.encode(msg);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return toHex(hash);
  }
  // find counter (simple loop). Stop after a reasonable count to avoid infinite loops.
  let counter = 0;
  let hash = '';
  const maxAttempts = 40000; // safety cap (adjust difficulty instead of raising this)
  while (counter < maxAttempts) {
    hash = await sha256hex(nonce + counter);
    if (hash.startsWith(prefix)) break;
    counter++;
    // yield occasionally so UI doesn't freeze
    if ((counter & 255) === 0) await new Promise(r=>setTimeout(r,0));
  }
  // Send result back to server
  try {
    const form = new FormData();
    form.append('antibot_challenge', nonce);
    form.append('antibot_ch_counter', String(counter));
    form.append('antibot_ch_hash', hash);
    form.append('antibot_ch_return', returnUrl);
    const resp = await fetch(window.location.pathname, {method:'POST', body: form, credentials: 'same-origin'});
    if (resp && resp.ok) {
      // On success the server will redirect to original URL or give OK
      const text = await resp.text();
      // If server responds with HTML, replace it; else reload
      if (text) {
        document.open(); document.write(text); document.close();
      } else {
        window.location.href = returnUrl;
      }
    } else {
      document.body.innerHTML = '<h1>Access denied</h1><p>Challenge failed.</p>';
    }
  } catch (e) {
    document.body.innerHTML = '<h1>Error</h1><p>'+String(e)+'</p>';
  }
})();
</script>
JSC;
    echo $js;
    echo "\n</body></html>";
    exit();
}

/* Handler: if this request is a POST with antibot_challenge fields, validate it */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['antibot_challenge']) && !empty($_POST['antibot_ch_counter']) && !empty($_POST['antibot_ch_hash'])) {
    // validate challenge
    $nonce = $_POST['antibot_challenge'];
    $counter = $_POST['antibot_ch_counter'];
    $hash = $_POST['antibot_ch_hash'];
    $session_nonce = $_SESSION['antibot_challenge_nonce'] ?? '';
    $session_time = $_SESSION['antibot_challenge_time'] ?? 0;
    // Expect nonce to match and not be old (>5 minutes)
    if ($nonce && $session_nonce && hash_equals($session_nonce, $nonce) && (time() - $session_time) < 300) {
        // compute expected hash server-side
        $expected = hash('sha256', $nonce . $counter);
        $prefix = $ANTIBOT_CONFIG['challenge_difficulty_hex_prefix'];
        if (hash_equals($expected, $hash) && strpos($expected, $prefix) === 0) {
            // success -> mark session verified for a period
            $_SESSION['antibot_challenge_verified'] = time();
            antibot_log('Challenge passed (nonce ok)');
            // redirect back if client provided return
            $ret = $_POST['antibot_ch_return'] ?? ($_SERVER['REQUEST_URI'] ?? '/');
            header('Location: ' . $ret);
            exit();
        } else {
            antibot_log('Challenge validation failed (hash mismatch or insufficient prefix)');
            http_response_code(403);
            echo "<h1>Forbidden</h1><p>Challenge failed.</p>";
            exit();
        }
    } else {
        antibot_log('Challenge validation failed (nonce mismatch or expired)');
        http_response_code(403);
        echo "<h1>Forbidden</h1><p>Challenge failed.</p>";
        exit();
    }
}

/* ========== High-level light runner (call at top of pages) ========== */
function antibot_run_light() {
    global $ANTIBOT_CONFIG;
    $client_ip = antibot_get_client_ip();
    if (in_array($client_ip, $ANTIBOT_CONFIG['allow_ips'])) return true;
    if (antibot_is_blocked_ip($client_ip)) { antibot_log('Blocked (temp blocks)'); antibot_kill(); }
    // rate limit
    antibot_check_rate_limit();

    // detect proxies/datacenters/Tor and handle challenge-first
    $probe = antibot_detect_proxy_datacenter($client_ip);
    if ($probe) {
        // If already verified recently, skip
        if (!empty($_SESSION['antibot_challenge_verified']) && (time() - $_SESSION['antibot_challenge_verified'] < 3600)) {
            // already verified
        } else {
            antibot_show_js_challenge_and_exit($probe['reason']);
        }
    }
    if (antibot_is_tor_exit($client_ip)) {
        if (!empty($_SESSION['antibot_challenge_verified']) && (time() - $_SESSION['antibot_challenge_verified'] < 3600)) {
            // verified
        } else {
            antibot_show_js_challenge_and_exit('Tor exit detected');
        }
    }

    return true;
}

/* ============== Quick install hint output (if file executed directly) ============== */
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    antibot_run_light();
    echo "AntiBot Shield: running lightweight checks.\n";
}
?>
